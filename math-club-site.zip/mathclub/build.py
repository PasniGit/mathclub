"""Build the Math Club site.

Usage:
    python build.py          # writes docs/index.html
    python build.py --serve  # builds, then previews at http://localhost:8000
"""

import sys
import shutil
from pathlib import Path

from jinja2 import Environment, FileSystemLoader, select_autoescape

import content

ROOT = Path(__file__).parent
TEMPLATES = ROOT / "templates"
OUTPUT = ROOT / "docs"


def build() -> Path:
    env = Environment(
        loader=FileSystemLoader(TEMPLATES),
        autoescape=select_autoescape(["html"]),
        trim_blocks=True,
        lstrip_blocks=True,
    )

    stylesheet = (TEMPLATES / "style.css.j2").read_text(encoding="utf-8")

    html = env.get_template("index.html").render(
        site=content.SITE,
        potw=content.PROBLEM_OF_THE_WEEK,
        archive=content.ARCHIVE,
        about=content.ABOUT,
        meetings=content.MEETINGS,
        competitions=content.COMPETITIONS,
        officers=content.OFFICERS,
        resources=content.RESOURCES,
        join=content.JOIN,
        stylesheet=stylesheet,
    )

    if OUTPUT.exists():
        shutil.rmtree(OUTPUT)
    OUTPUT.mkdir(parents=True)
    page = OUTPUT / "index.html"
    page.write_text(html, encoding="utf-8")

    # Tells GitHub Pages to serve the files as-is.
    (OUTPUT / ".nojekyll").write_text("", encoding="utf-8")

    print(f"Built {page.relative_to(ROOT)}  ({page.stat().st_size / 1024:.1f} KB)")
    return page


def serve() -> None:
    import http.server
    import socketserver
    import functools

    handler = functools.partial(
        http.server.SimpleHTTPRequestHandler, directory=str(OUTPUT)
    )
    with socketserver.TCPServer(("", 8000), handler) as httpd:
        print("Preview at http://localhost:8000  (Ctrl+C to stop)")
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            print("\nStopped.")


if __name__ == "__main__":
    build()
    if "--serve" in sys.argv:
        serve()
